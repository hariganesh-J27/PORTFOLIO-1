import React, { useState } from 'react';
import LogoLoop from './LogoLoop';
import { Zap, Brain, Navigation, Database, Film, Cpu, ArrowRight, Github, X, GitBranch, Layers } from 'lucide-react';

const projectArchitectureDetails = {
  scoliosis: {
    title: 'Wearable Scoliosis Detection System',
    subtitle: 'Multi-Sensor Wearable Vest with Real-Time Neural Cobb Angle Estimation',
    badge: '★ FEATURED HARDWARE & AI',
    date: 'APRIL — 2024',
    metrics: [
      { label: 'Cobb Angle Accuracy', value: '94.2%' },
      { label: 'Streaming Latency', value: '< 15ms' },
      { label: 'Sensor Sampling', value: '100 Hz' },
      { label: 'Battery Life', value: '14+ Hours' }
    ],
    architectureFlow: [
      {
        step: '01',
        title: 'Multi-Sensor Acquisition',
        desc: 'Dual ADXL345 3-axis accelerometer sensor arrays placed along the thoracic and lumbar spinal column capture real-time pitch, roll, and tilt angles at 100 Hz.'
      },
      {
        step: '02',
        title: 'Edge Microcontroller & Kalman Filter',
        desc: 'ESP32 dual-core SoC runs an onboard discrete Kalman filter for sensor fusion and noise cancellation, computing raw tilt vector matrices.'
      },
      {
        step: '03',
        title: 'Low-Latency WebSocket Streaming',
        desc: 'Bi-directional async WebSocket telemetry packets transmitted over 2.4GHz Wi-Fi with sub-15ms round-trip latency to the local inference server.'
      },
      {
        step: '04',
        title: 'Neural Cobb Angle Regression',
        desc: 'PyTorch deep regression model & Random Forest ensemble predict coronal plane spinal deformity degrees with 94.2% accuracy against clinical benchmarks.'
      },
      {
        step: '05',
        title: '3D Orthopedic Digital Twin',
        desc: 'Interactive 3D WebGL anatomical spine visualizer renders posture anomalies in real time with automated alert triggers for posture correction.'
      }
    ],
    techStack: [
      { category: 'Hardware & Embedded', items: ['ESP32 Dual-Core Microcontroller', 'ADXL345 3-Axis Digital Accelerometers', 'I2C Bus Communication Protocol', 'LiPo Power Management Circuitry'] },
      { category: 'Machine Learning & AI', items: ['PyTorch Neural Regression Models', 'Scikit-Learn Random Forest Regressor', 'Extended Kalman Filtering (EKF)', 'NumPy Matrix Kinematics'] },
      { category: 'Backend & Telemetry', items: ['Python Asyncio WebSocket Server', 'FastAPI REST Ingestion Endpoints', 'JSON Telemetry Framing Protocol'] },
      { category: 'Frontend & 3D Visualization', items: ['Three.js / WebGL 3D Spine Mesh', 'HTML5 Canvas Real-Time Plotting', 'Tailwind CSS UI Dashboard'] }
    ],
    github: 'https://github.com'
  },
  'disease-prediction': {
    title: 'Disease Prediction Using Random Forest',
    subtitle: 'Clinical Diagnostic Machine Learning Pipeline with Cross-Validation & Feature Importance',
    badge: 'ML SPOTLIGHT',
    date: 'OCT — 2024',
    metrics: [
      { label: '10-Fold CV Accuracy', value: '94.8%' },
      { label: 'Sensitivity / Recall', value: '96.2%' },
      { label: 'ROC-AUC Score', value: '0.981' },
      { label: 'Inference Time', value: '< 8ms' }
    ],
    architectureFlow: [
      {
        step: '01',
        title: 'Clinical Data Ingestion & Sanitization',
        desc: 'Ingests patient health indicators (blood glucose, blood pressure, BMI, insulin, age, skin fold thickness) with outlier detection and mean/median imputation.'
      },
      {
        step: '02',
        title: 'Feature Scaling & Transformation',
        desc: 'StandardScaler normalization and power transformations applied to prevent scale bias across heterogeneous clinical biomarker dimensions.'
      },
      {
        step: '03',
        title: 'Ensemble Model Architecture',
        desc: 'Random Forest classifier trained with 200 decision tree estimators, utilizing bootstrap aggregation and Gini impurity criterion for node splitting.'
      },
      {
        step: '04',
        title: 'Cross-Validation & Hyperparameter Tuning',
        desc: 'Stratified 10-fold cross-validation with GridSearch optimization over tree depth, minimum sample splits, and feature subsets achieving 94.8% accuracy.'
      },
      {
        step: '05',
        title: 'Interpretability & Decision Support',
        desc: 'Extracts relative Gini importance rankings and ROC-AUC curve diagnostics to generate transparent clinical risk reports for healthcare practitioners.'
      }
    ],
    techStack: [
      { category: 'Core Algorithms', items: ['Random Forest Classifier', 'Decision Trees Ensemble', 'Bootstrap Aggregation (Bagging)', 'Stratified K-Fold Cross-Validation'] },
      { category: 'Data Science & ML Libraries', items: ['Python 3.11', 'Scikit-Learn Ensemble & Preprocessing', 'Pandas DataFrame Analysis', 'NumPy Vectorized Operations'] },
      { category: 'Diagnostics & Evaluation', items: ['ROC-AUC Curve Analysis', 'Confusion Matrix Verification', 'Gini Feature Importance Scoring', 'Classification Recall Optimization'] },
      { category: 'Deployment & Export', items: ['Joblib Model Serialization', 'FastAPI Diagnostic Microservice', 'Docker Container Packaging'] }
    ],
    github: 'https://github.com'
  },
  drone: {
    title: 'ROS2 Autonomous Drone & Gazebo Telemetry',
    subtitle: 'Spatial-Temporal Trajectory Forecasting & Simulated Obstacle Avoidance',
    badge: 'ROBOTICS AI',
    date: 'JAN — 2025',
    metrics: [
      { label: 'Simulation Fidelity', value: '60 FPS Gazebo' },
      { label: 'Trajectory Horizon', value: '5.0s Lookahead' },
      { label: 'Avoidance Success', value: '98.4%' },
      { label: 'Control Loop Rate', value: '50 Hz' }
    ],
    architectureFlow: [
      {
        step: '01',
        title: '3D Simulation Environment',
        desc: 'Gazebo 11 physics engine simulates quadrotor rigid-body aerodynamics, gravity, thrust coefficients, and complex urban obstacle meshes.'
      },
      {
        step: '02',
        title: 'Perception & Odometry Node',
        desc: 'Simulated 360° LiDAR, IMU, and stereo camera sensors stream point clouds and transform frames (/tf) across ROS2 publish-subscribe topics.'
      },
      {
        step: '03',
        title: 'LSTM Spatial-Temporal Forecasting',
        desc: 'PyTorch deep LSTM recurrent neural network ingests sequential historical flight coordinate vectors and predicts future 3D collision risk zones.'
      },
      {
        step: '04',
        title: 'Real-Time Path Planning',
        desc: 'High-performance C++ ROS2 node computes dynamically feasible spline trajectories using 3D A* search and artificial potential field avoidance.'
      },
      {
        step: '05',
        title: 'MAVLink Flight Control Actuation',
        desc: 'Translates trajectory waypoints into MAVLink setpoint velocity commands streamed to the PX4 autopilot simulation layer at 50 Hz.'
      }
    ],
    techStack: [
      { category: 'Robotics Middleware', items: ['ROS2 Humble Hawksbill', 'rclcpp (C++ Client Library)', 'rclpy (Python Client)', 'ROS2 Transform Framework (TF2)'] },
      { category: 'Simulation & Visualization', items: ['Gazebo 11 Physics Simulator', 'RViz2 3D Pointcloud Visualizer', 'URDF / SDF Multirotor Kinematics'] },
      { category: 'Deep Learning & Forecasting', items: ['PyTorch LSTM Networks', 'Time-Series Sequence Modeling', 'Spatial-Temporal Matrix Tensor Math'] },
      { category: 'Flight Protocols & Hardware', items: ['PX4 Autopilot Software', 'MAVLink & MAVROS Protocol', 'Ubuntu Linux 22.04 LTS'] }
    ],
    github: 'https://github.com'
  },
  'movie-ticket': {
    title: 'Movie Ticket Booking System',
    subtitle: 'High-Concurrency ACID Relational DBMS with Zero Double-Booking Guarantee',
    badge: 'DBMS & CONCURRENCY',
    date: 'AUG — 2024',
    metrics: [
      { label: 'Double-Booking Conflict', value: '0.00%' },
      { label: 'Query Execution', value: '< 18ms' },
      { label: 'Isolation Level', value: 'SERIALIZABLE' },
      { label: 'Peak Capacity', value: '1,000+ Req/s' }
    ],
    architectureFlow: [
      {
        step: '01',
        title: 'Concurrent Reservation Request',
        desc: 'High-traffic ticket reservation requests submitted by multiple simultaneous users requesting specific seat allocations across theatre screens.'
      },
      {
        step: '02',
        title: 'ACID Transaction & Row-Level Locking',
        desc: 'PostgreSQL engine initiates explicit transactions with SELECT FOR UPDATE row-level pessimistic locking, isolating selected seat rows from race conditions.'
      },
      {
        step: '03',
        title: 'Atomic State Transition',
        desc: 'PL/pgSQL stored procedures verify availability and execute atomic status updates (Available -> Reserved -> Confirmed) with zero window for collision.'
      },
      {
        step: '04',
        title: 'Normalized Relational Persistence',
        desc: '3NF/BCNF schema maintains strict relational integrity across users, shows, auditoriums, seating layouts, pricing tiers, and audit logs.'
      },
      {
        step: '05',
        title: 'Automated Invoice & Ticket Generation',
        desc: 'Dispatches instant booking confirmation token and PDF receipt generation while committing transactions to the persistent storage layer.'
      }
    ],
    techStack: [
      { category: 'Database Engine', items: ['PostgreSQL 16', 'PL/pgSQL Stored Procedures & Triggers', 'Row-Level Locking (SELECT FOR UPDATE)', 'ACID SERIALIZABLE Isolation'] },
      { category: 'Database Design', items: ['Relational Normalization (1NF — BCNF)', 'B-Tree & Composite Indexing', 'Foreign Key Cascade Constraints', 'Connection Pooling Optimization'] },
      { category: 'Backend & APIs', items: ['Node.js / Python FastAPI', 'Async Database Connection Pool', 'RESTful Reservation Endpoints'] },
      { category: 'Security & Integrity', items: ['Parameterized SQL Queries (SQLi Proof)', 'Role-Based Database Access', 'Transaction Rollback Logging'] }
    ],
    github: 'https://github.com'
  },
  hospital: {
    title: 'Hospital Management System',
    subtitle: 'Enterprise Relational Database Architecture with Role-Based Access Control',
    badge: 'SQL & RELATIONAL DB',
    date: 'DEC — 2024',
    metrics: [
      { label: 'Schema Integrity', value: '100% 3NF' },
      { label: 'Audit Trail', value: 'Complete Logging' },
      { label: 'Security Role Separation', value: '4 Tiers (RBAC)' },
      { label: 'Query Performance', value: '< 22ms' }
    ],
    architectureFlow: [
      {
        step: '01',
        title: 'Patient Intake & Triage Processing',
        desc: 'Ingests patient medical history, insurance coverage, and triage vital parameters into normalized electronic health record (EHR) schemas.'
      },
      {
        step: '02',
        title: 'Role-Based Access Control (RBAC)',
        desc: 'Database security policies enforce permission boundaries restricting data access between doctors, nurses, pharmacists, and billing administrators.'
      },
      {
        step: '03',
        title: 'Consultation & Pharmacy Triggers',
        desc: 'Doctor prescription submissions automatically invoke database triggers that decrement pharmacy stock inventory and populate patient dispensing queues.'
      },
      {
        step: '04',
        title: 'Automated Billing Stored Procedures',
        desc: 'Stored procedures aggregate room charges, doctor consultation fees, diagnostic lab tests, and medication costs into unified itemized invoices.'
      },
      {
        step: '05',
        title: 'Audit Logging & Clinical Analytics',
        desc: 'System event tables log every read/write operation for medical regulatory compliance while generating hospital occupancy & revenue analytics.'
      }
    ],
    techStack: [
      { category: 'Database & SQL', items: ['PostgreSQL / MySQL', 'Complex SQL Joins & Nested Subqueries', 'Database Event Triggers', 'PL/SQL Stored Procedures & Views'] },
      { category: 'Security & Compliance', items: ['Role-Based Access Control (RBAC)', 'Encrypted Patient Data Columns', 'Automated Audit Trail Logging', 'HIPAA-Aligned Schema Boundaries'] },
      { category: 'Architecture & Modeling', items: ['Entity-Relationship (ER) Data Modeling', 'Third Normal Form (3NF) Normalization', 'Referential Integrity Constraints'] },
      { category: 'Interface & Integration', items: ['HTML5 / CSS3 Admin Dashboard', 'RESTful API Services', 'Relational Report Generator'] }
    ],
    github: 'https://github.com'
  }
};

export default function Projects() {
  const [filter, setFilter] = useState('all');
  const [activeModalProject, setActiveModalProject] = useState(null);

  const projects = [
    {
      id: 'scoliosis',
      title: 'Wearable Scoliosis Detection System',
      category: 'hardware',
      badge: '★ FEATURED HARDWARE',
      date: 'APRIL — 2024',
      metrics: ['🎯 94.2% Cobb Angle', '⚡ < 15ms Latency', '📡 4x ADXL345'],
      description: 'IoT wearable posture monitoring system using ESP32 with accelerometer arrays fed into neural regression models.',
      tech: ['ESP32', 'PyTorch', 'ADXL345', 'WebSockets'],
      icon: Zap,
    },
    {
      id: 'disease-prediction',
      title: 'Disease Prediction Using Random Forest',
      category: 'ml',
      badge: 'ML SPOTLIGHT',
      date: 'OCT — 2024',
      metrics: ['🎯 94.8% CV Accuracy', '🌲 Gini Importance'],
      description: 'Predictive clinical diagnostic machine learning pipeline evaluating patient health parameters with cross-validation.',
      tech: ['Python', 'Scikit-Learn', 'Random Forest', 'Pandas'],
      icon: Brain,
    },
    {
      id: 'drone',
      title: 'ROS2 Autonomous Drone Simulation',
      category: 'hardware',
      badge: 'ROBOTICS AI',
      date: 'JAN — 2025',
      metrics: ['🚁 ROS2 Humble Flight', '🧠 PyTorch LSTM Trajectory'],
      description: 'Spatial-temporal trajectory forecasting pipeline using ROS2 nodes, PyTorch LSTM networks, and Gazebo 3D simulation.',
      tech: ['ROS2', 'Gazebo', 'PyTorch LSTM', 'C++'],
      icon: Navigation,
    },
    {
      id: 'movie-ticket',
      title: 'Movie Ticket Booking System',
      category: 'cloud',
      badge: 'DBMS & CONCURRENCY',
      date: 'AUG — 2024',
      metrics: ['🎟️ High-Concurrency ACID', '⚡ Sub-Second Query'],
      description: 'Relational database schema and stored procedures preventing race condition double-booking with ACID transactions.',
      tech: ['PostgreSQL', 'SQL Transactions', 'Node.js', 'Redis'],
      icon: Film,
    },
    {
      id: 'hospital',
      title: 'Hospital Management Architecture',
      category: 'cloud',
      badge: 'SQL & RELATIONAL DB',
      date: 'DEC — 2024',
      metrics: ['🏥 RBAC Data Security', '📊 Automated Billing'],
      description: 'End-to-end database management system for hospital operations, patient records, staff scheduling, and billing.',
      tech: ['PostgreSQL', 'Stored Procedures', 'RBAC Security', 'ER Modeling'],
      icon: Database,
    },
  ];

  const filteredProjects = filter === 'all'
    ? projects
    : projects.filter(p => p.category === filter || (filter === 'hardware' && (p.category === 'hardware' || p.category === 'ml')));

  const modalData = activeModalProject ? projectArchitectureDetails[activeModalProject] : null;

  return (
    <section id="projects" className="section" style={{ position: 'relative', zIndex: 2, paddingTop: '7.5rem', background: '#FDFFF5' }}>
      <div className="container" style={{ maxWidth: '1280px', margin: '0 auto', padding: '0 2.5rem' }}>

        {/* Chapter 04 Watermark */}
        <div style={{ marginBottom: '2.5rem', textAlign: 'left' }}>
          <div style={{ fontFamily: "'Outfit', sans-serif", fontSize: 'clamp(3.5rem, 7vw, 5.5rem)', fontWeight: 900, color: 'rgba(0, 0, 0, 0.08)', lineHeight: 0.9, marginBottom: '0.2rem', letterSpacing: '-0.02em' }}>
            04
          </div>
          <div style={{ fontFamily: 'var(--font-code)', fontSize: '0.75rem', fontWeight: 700, color: '#71717a', letterSpacing: '0.25em', textTransform: 'uppercase', marginBottom: '0.5rem' }}>
            CHAPTER 04
          </div>
          <h2 style={{ fontFamily: "'Outfit', sans-serif", fontSize: 'clamp(2.4rem, 4.5vw, 3.4rem)', fontWeight: 900, color: '#000000', letterSpacing: '-0.02em', textTransform: 'uppercase', margin: 0 }}>
            SELECTED WORKS
          </h2>
        </div>

        {/* Filter Category Badges */}
        <div style={{ display: 'flex', justifyContent: 'center', gap: '0.75rem', flexWrap: 'wrap', marginTop: '1.5rem', marginBottom: '2.5rem', position: 'relative', zIndex: 10 }}>
          {[
            { id: 'all', label: 'All Systems' },
            { id: 'hardware', label: 'Wearable IoT & Robotics' },
            { id: 'ml', label: 'AI / ML & Vision' },
            { id: 'cloud', label: 'Cloud & Telemetry' },
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => setFilter(cat.id)}
              style={{
                border: filter === cat.id ? '1px solid #000000' : '1px solid rgba(0,0,0,0.2)',
                color: filter === cat.id ? '#FDFFF5' : '#27272a',
                background: filter === cat.id ? '#000000' : 'rgba(0,0,0,0.05)',
                padding: '0.55rem 1.25rem',
                borderRadius: '50px',
                fontWeight: 700,
                cursor: 'pointer',
                transition: 'all 0.2s ease',
              }}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* React Bits LogoLoop Infinite Projects Marquee */}
      <div className="project-loop-wrapper">
        <LogoLoop
          logos={filteredProjects}
          speed={60}
          direction="left"
          gap={32}
          pauseOnHover={true}
          hoverSpeed={0}
          fadeOut={true}
          fadeOutColor="#FDFFF5"
          ariaLabel="Featured engineering projects marquee"
          renderItem={(project, key) => {
            return (
              <div key={key} className="project-loop-card inspect-project-trigger" data-project={project.id}>
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1rem', flexWrap: 'wrap', gap: '0.5rem' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                      <span style={{ background: '#000000', border: '1px solid #000000', padding: '0.2rem 0.65rem', borderRadius: '50px', fontFamily: 'var(--font-code)', fontSize: '0.72rem', color: '#FDFFF5', fontWeight: 700 }}>
                        {project.badge}
                      </span>
                      <span className="cosmic-date-tag" style={{ fontSize: '0.75rem', padding: '0.2rem 0.65rem', background: 'rgba(0,0,0,0.06)', border: '1px solid rgba(0,0,0,0.2)', color: '#000000', borderRadius: '4px', fontFamily: 'var(--font-code)' }}>
                        {project.date}
                      </span>
                    </div>
                    <a href="https://github.com" target="_blank" rel="noreferrer" className="bento-icon-btn" title="GitHub Repository" style={{ color: '#000000', transition: 'color 0.3s ease' }}>
                      <Github size={18} />
                    </a>
                  </div>

                  <h3 style={{ fontSize: '1.35rem', fontWeight: 800, color: '#000000', margin: '0 0 0.75rem 0', transition: 'color 0.3s ease', lineHeight: 1.3 }}>
                    {project.title}
                  </h3>

                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.4rem', marginBottom: '1rem' }}>
                    {project.metrics.map((m, mIdx) => (
                      <span key={mIdx} className="metric-pill-badge" style={{ background: 'rgba(0, 0, 0, 0.08)', border: '1px solid rgba(0, 0, 0, 0.25)', color: '#000000', fontSize: '0.74rem', fontWeight: 700, padding: '0.2rem 0.6rem', borderRadius: '50px', fontFamily: 'var(--font-code)', transition: 'all 0.3s ease' }}>
                        {m}
                      </span>
                    ))}
                  </div>

                  <p className="project-card-desc" style={{ color: '#52525b', fontSize: '0.9rem', lineHeight: 1.6, margin: '0 0 1.25rem 0', transition: 'color 0.3s ease' }}>
                    {project.description}
                  </p>

                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.35rem', marginBottom: '1.5rem' }}>
                    {project.tech.map((t, tIdx) => (
                      <span key={tIdx} className="cosmic-pill-tag" style={{ padding: '0.25rem 0.65rem', fontSize: '0.75rem', background: 'rgba(0,0,0,0.06)', border: '1px solid rgba(0,0,0,0.2)', color: '#000000', borderRadius: '4px', fontFamily: 'var(--font-code)', transition: 'all 0.3s ease' }}>
                        {t}
                      </span>
                    ))}
                  </div>
                </div>

                <button
                  onClick={() => setActiveModalProject(project.id)}
                  className="btn btn-secondary inspect-project-btn"
                  style={{ width: '100%', padding: '0.7rem 1rem', fontSize: '0.85rem', justifyContent: 'center', background: '#000000', color: '#FDFFF5', border: '1px solid #000000', borderRadius: '6px', cursor: 'pointer', fontFamily: 'var(--font-code)', fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', transition: 'all 0.3s ease' }}
                >
                  <span>Inspect Architecture Flow</span>
                  <ArrowRight size={15} style={{ marginLeft: '0.4rem' }} />
                </button>
              </div>
            );
          }}
        />
      </div>

      {/* Architecture Flow & Tech Stack Modal */}
      {modalData && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0, 0, 0, 0.65)', backdropFilter: 'blur(8px)', zIndex: 9999, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '1.5rem' }}>
          <div style={{ background: '#FDFFF5', border: '1.5px solid #000000', borderRadius: '16px', maxWidth: '850px', width: '100%', maxHeight: '88vh', overflowY: 'auto', padding: '2.5rem', position: 'relative', boxShadow: '0 25px 60px rgba(0, 0, 0, 0.35)' }}>
            
            {/* Close Button */}
            <button
              onClick={() => setActiveModalProject(null)}
              style={{ position: 'absolute', top: '1.25rem', right: '1.25rem', background: 'rgba(0,0,0,0.06)', border: '1px solid rgba(0,0,0,0.2)', borderRadius: '50%', width: '36px', height: '36px', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: '#000000' }}
            >
              <X size={18} />
            </button>

            {/* Modal Header */}
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '0.5rem', marginBottom: '0.6rem' }}>
              <span style={{ background: '#000000', color: '#FDFFF5', padding: '0.25rem 0.75rem', borderRadius: '50px', fontFamily: 'var(--font-code)', fontSize: '0.72rem', fontWeight: 800, letterSpacing: '0.08em', textTransform: 'uppercase' }}>
                {modalData.badge}
              </span>
              <span style={{ fontFamily: 'var(--font-code)', fontSize: '0.78rem', fontWeight: 700, color: '#71717a' }}>
                {modalData.date}
              </span>
            </div>

            <h2 style={{ fontFamily: "'Outfit', sans-serif", fontSize: 'clamp(1.6rem, 3.5vw, 2.2rem)', fontWeight: 900, color: '#000000', lineHeight: 1.15, margin: '0 0 0.4rem 0' }}>
              {modalData.title}
            </h2>
            <div style={{ fontFamily: 'var(--font-code)', fontSize: '0.85rem', fontWeight: 700, color: '#52525b', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: '1.5rem' }}>
              {modalData.subtitle}
            </div>

            {/* Metrics */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(130px, 1fr))', gap: '0.75rem', marginBottom: '2rem' }}>
              {modalData.metrics.map((m, idx) => (
                <div key={idx} style={{ background: 'rgba(0, 0, 0, 0.04)', border: '1px solid rgba(0, 0, 0, 0.12)', padding: '0.75rem 1rem', borderRadius: '8px' }}>
                  <div style={{ fontFamily: 'var(--font-code)', fontSize: '0.7rem', fontWeight: 700, color: '#71717a', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: '0.2rem' }}>
                    {m.label}
                  </div>
                  <div style={{ fontFamily: "'Outfit', sans-serif", fontSize: '1.25rem', fontWeight: 900, color: '#000000' }}>
                    {m.value}
                  </div>
                </div>
              ))}
            </div>

            {/* Architecture Flow */}
            <div style={{ marginBottom: '2rem' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '1.1rem', borderBottom: '1px solid rgba(0,0,0,0.1)', paddingBottom: '0.5rem' }}>
                <GitBranch size={20} color="#000000" />
                <h3 style={{ fontFamily: "'Outfit', sans-serif", fontSize: '1.25rem', fontWeight: 900, color: '#000000', margin: 0, textTransform: 'uppercase', letterSpacing: '0.04em' }}>
                  End-to-End Architecture Flow
                </h3>
              </div>
              <div>
                {modalData.architectureFlow.map((f, idx) => (
                  <div key={idx} style={{ position: 'relative', display: 'flex', gap: '1rem', marginBottom: idx === modalData.architectureFlow.length - 1 ? '0' : '1.25rem' }}>
                    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                      <div style={{ width: '32px', height: '32px', borderRadius: '50%', background: '#000000', color: '#FDFFF5', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'var(--font-code)', fontSize: '0.78rem', fontWeight: 800, flexShrink: 0, boxShadow: '0 2px 8px rgba(0,0,0,0.2)' }}>
                        {f.step}
                      </div>
                      {idx < modalData.architectureFlow.length - 1 && (
                        <div style={{ width: '2px', flex: 1, background: 'rgba(0,0,0,0.15)', margin: '0.35rem 0' }}></div>
                      )}
                    </div>
                    <div style={{ background: '#FDFFF5', border: '1px solid rgba(0,0,0,0.12)', padding: '0.9rem 1.2rem', borderRadius: '8px', flex: 1, boxShadow: '0 2px 8px rgba(0,0,0,0.02)' }}>
                      <div style={{ fontFamily: "'Outfit', sans-serif", fontSize: '1.05rem', fontWeight: 800, color: '#000000', marginBottom: '0.25rem' }}>
                        {f.title}
                      </div>
                      <p style={{ fontSize: '0.88rem', color: '#52525b', lineHeight: 1.55, margin: 0 }}>
                        {f.desc}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Tech Stack Used */}
            <div style={{ marginBottom: '2rem' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '1.1rem', borderBottom: '1px solid rgba(0,0,0,0.1)', paddingBottom: '0.5rem' }}>
                <Layers size={20} color="#000000" />
                <h3 style={{ fontFamily: "'Outfit', sans-serif", fontSize: '1.25rem', fontWeight: 900, color: '#000000', margin: 0, textTransform: 'uppercase', letterSpacing: '0.04em' }}>
                  Tech Stack Used &amp; Engineering Tooling
                </h3>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '1rem' }}>
                {modalData.techStack.map((cat, idx) => (
                  <div key={idx} style={{ background: '#FDFFF5', border: '1px solid rgba(0,0,0,0.12)', padding: '1rem 1.25rem', borderRadius: '8px' }}>
                    <div style={{ fontFamily: 'var(--font-code)', fontSize: '0.75rem', fontWeight: 800, color: '#000000', textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: '0.6rem', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                      <span style={{ display: 'inline-block', width: '6px', height: '6px', borderRadius: '50%', background: '#000000' }}></span>
                      {cat.category}
                    </div>
                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.45rem' }}>
                      {cat.items.map((item, itemIdx) => (
                        <span key={itemIdx} style={{ background: 'rgba(0,0,0,0.05)', border: '1px solid rgba(0,0,0,0.18)', color: '#18181b', padding: '0.25rem 0.65rem', borderRadius: '4px', fontFamily: 'var(--font-code)', fontSize: '0.75rem', font-weight: 700 }}>
                          {item}
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Action Row */}
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: '1rem', borderTop: '1px solid rgba(0,0,0,0.1)', paddingTop: '1.25rem' }}>
              <a href={modalData.github} target="_blank" rel="noopener noreferrer" style={{ background: '#000000', color: '#FDFFF5', border: '1.5px solid #000000', padding: '0.65rem 1.4rem', borderRadius: '6px', fontFamily: 'var(--font-code)', fontSize: '0.78rem', fontWeight: 700, textDecoration: 'none', display: 'inline-flex', alignItems: 'center', gap: '0.5rem', letterSpacing: '0.08em', textTransform: 'uppercase' }}>
                <span>Explore Source Repository</span>
                <Github size={15} />
              </a>
            </div>

          </div>
        </div>
      )}

    </section>
  );
}
