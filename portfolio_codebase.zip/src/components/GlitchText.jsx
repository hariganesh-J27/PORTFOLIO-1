import React from 'react';
import './GlitchText.css';

const GlitchText = ({
  children = "I'm Hari Ganesh",
  speed = 1,
  enableShadows = true,
  enableOnHover = false,
  className = ''
}) => {
  const inlineStyles = {
    '--after-duration': `${speed * 3}s`,
    '--before-duration': `${speed * 2}s`,
    '--after-shadow': enableShadows ? '-5px 0 #00ff66' : 'none',
    '--before-shadow': enableShadows ? '5px 0 #10b981' : 'none'
  };

  const hoverClass = enableOnHover ? 'enable-on-hover' : '';

  return (
    <div className={`glitch ${hoverClass} ${className}`} style={inlineStyles} data-text={children}>
      {children}
    </div>
  );
};

export default GlitchText;
