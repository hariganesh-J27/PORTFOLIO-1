import React, { useState, useEffect, useRef } from 'react';
import { Award, Cloud, ShieldCheck, X, ExternalLink, Download, CheckCircle2, Calendar, FileText, ChevronRight } from 'lucide-react';
import './ModalCards.css';

export default function ModalCards({ cards = [] }) {
  const [selectedCard, setSelectedCard] = useState(null);
  const modalContentRef = useRef(null);

  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === 'Escape') {
        setSelectedCard(null);
      }
    };
    if (selectedCard) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [selectedCard]);

  return (
    <div className="modal-cards-container">
      {/* Cards Grid */}
      <div className="modal-cards-grid">
        {cards.map((card) => {
          const isSelected = selectedCard?.id === card.id;
          return (
            <div
              key={card.id}
              className={`modal-card-item ${isSelected ? 'modal-card-item--hidden' : ''}`}
              onClick={() => setSelectedCard(card)}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  setSelectedCard(card);
                }
              }}
              aria-haspopup="dialog"
            >
              {/* Card Image Container */}
              <div className="modal-card-image-wrap">
                <img src={card.image} alt={card.title} loading="lazy" />
                <div className="modal-card-image-overlay" />
                <span className="modal-card-zoom-badge">
                  <span>Click to Expand</span>
                  <ChevronRight size={14} />
                </span>
              </div>

              {/* Card Header & Content */}
              <div className="modal-card-body">
                <div className="modal-card-meta-row">
                  <div className="modal-card-icon-box">
                    <Award size={20} />
                  </div>
                  <span className="modal-card-date-badge">{card.date}</span>
                </div>

                <h3 className="modal-card-title">{card.title}</h3>
                <div className="modal-card-issuer">{card.issuer}</div>
                <p className="modal-card-desc">{card.description}</p>

                <div className="modal-card-footer">
                  <div className="modal-card-id-tag">
                    <span className="modal-card-id-label">Official Credential</span>
                    <span className="modal-card-id-val">{card.certId}</span>
                  </div>
                  <button className="modal-card-expand-btn">
                    <span>Inspect Full Certificate</span>
                    <ChevronRight size={16} />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Expanded Full-Screen Modal */}
      {selectedCard && (
        <div className="modal-cards-overlay" onClick={() => setSelectedCard(null)}>
          <div
            className="modal-cards-dialog"
            ref={modalContentRef}
            onClick={(e) => e.stopPropagation()}
            role="dialog"
            aria-modal="true"
          >
            {/* Close Button */}
            <button
              className="modal-cards-close-btn"
              onClick={() => setSelectedCard(null)}
              aria-label="Close certificate modal"
            >
              <X size={20} />
            </button>

            {/* Dialog Content Grid */}
            <div className="modal-cards-dialog-content">
              {/* Left Column: Full Resolution Image Box */}
              <div className="modal-cards-preview-side">
                <div className="modal-cards-full-img-wrap">
                  <img
                    src={selectedCard.image}
                    alt={selectedCard.title}
                    className="modal-cards-full-img"
                  />
                </div>
                <div className="modal-cards-verified-ribbon">
                  <ShieldCheck size={18} color="#16a34a" />
                  <span>Cryptographically Verified Credential &amp; Academic Issuer</span>
                </div>
              </div>

              {/* Right Column: Detailed Credential Metadata */}
              <div className="modal-cards-info-side">
                <div className="modal-cards-dialog-header">
                  <div className="modal-cards-dialog-issuer">{selectedCard.issuer}</div>
                  <h2 className="modal-cards-dialog-title">{selectedCard.title}</h2>
                  <div className="modal-cards-date-pill">
                    <Calendar size={14} />
                    <span>Awarded on {selectedCard.date}</span>
                  </div>
                </div>

                <div className="modal-cards-details-section">
                  <h4 className="modal-cards-section-heading">Credential Overview</h4>
                  <p className="modal-cards-long-desc">{selectedCard.description}</p>
                </div>

                {selectedCard.skills && (
                  <div className="modal-cards-details-section">
                    <h4 className="modal-cards-section-heading">Verified Competencies</h4>
                    <div className="modal-cards-skills-tags">
                      {selectedCard.skills.map((skill, idx) => (
                        <span key={idx} className="modal-cards-skill-pill">
                          <CheckCircle2 size={13} color="#000000" />
                          <span>{skill}</span>
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                <div className="modal-cards-id-box">
                  <div className="modal-cards-id-row">
                    <span className="modal-cards-meta-label">Credential Identification:</span>
                    <span className="modal-cards-meta-value">{selectedCard.certId}</span>
                  </div>
                  <div className="modal-cards-id-row">
                    <span className="modal-cards-meta-label">Recipient:</span>
                    <span className="modal-cards-meta-value">Hari Ganesh J</span>
                  </div>
                </div>

                {/* Actions */}
                <div className="modal-cards-actions">
                  <button
                    className="btn btn-primary modal-cards-action-btn"
                    onClick={() => window.print()}
                  >
                    <Download size={16} />
                    <span>Print / Save PDF</span>
                  </button>
                  <button
                    className="btn btn-secondary modal-cards-action-btn"
                    onClick={() => setSelectedCard(null)}
                  >
                    <span>Close Inspection</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
