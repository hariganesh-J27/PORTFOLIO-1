import React, { useRef } from 'react';
import './TextScatter.css';

export default function TextScatter({ text = "I'M HARI\nGANESH J", className = "", dot = true }) {
  const containerRef = useRef(null);

  const lines = text.split('\n');

  const handleCharHover = (e) => {
    const el = e.currentTarget;
    if (el._isScattering) return;
    el._isScattering = true;

    const rect = el.getBoundingClientRect();
    const charCenterX = rect.left + rect.width / 2;
    const charCenterY = rect.top + rect.height / 2;

    const dx = charCenterX - e.clientX;
    const dy = charCenterY - e.clientY;
    const angle = Math.atan2(dy, dx);

    const distance = 40 + Math.random() * 85;
    const offsetX = Math.cos(angle) * distance;
    const offsetY = Math.sin(angle) * distance;
    const rotation = (Math.random() - 0.5) * 80;
    const scale = 0.95 + Math.random() * 0.35;

    el.classList.add('is-scattered');
    el.style.transform = `translate3d(${offsetX}px, ${offsetY}px, 0) rotate(${rotation}deg) scale(${scale})`;

    setTimeout(() => {
      el.classList.remove('is-scattered');
      el.style.transform = 'translate3d(0, 0, 0) rotate(0deg) scale(1)';
      setTimeout(() => {
        el._isScattering = false;
      }, 650);
    }, 450);
  };

  const handleClick = (e) => {
    if (!containerRef.current) return;
    const allChars = containerRef.current.querySelectorAll('.scatter-char:not(.space), .scatter-dot');
    const clickX = e.clientX;
    const clickY = e.clientY;

    allChars.forEach((el, index) => {
      setTimeout(() => {
        if (el._isScattering) return;
        el._isScattering = true;

        const rect = el.getBoundingClientRect();
        const cx = rect.left + rect.width / 2;
        const cy = rect.top + rect.height / 2;
        const angle = Math.atan2(cy - clickY, cx - clickX) + (Math.random() - 0.5);
        const distance = 50 + Math.random() * 90;
        const offsetX = Math.cos(angle) * distance;
        const offsetY = Math.sin(angle) * distance;
        const rotation = (Math.random() - 0.5) * 80;

        el.classList.add('is-scattered');
        el.style.transform = `translate3d(${offsetX}px, ${offsetY}px, 0) rotate(${rotation}deg)`;

        setTimeout(() => {
          el.classList.remove('is-scattered');
          el.style.transform = 'translate3d(0, 0, 0) rotate(0deg)';
          setTimeout(() => {
            el._isScattering = false;
          }, 650);
        }, 500);
      }, index * 20);
    });
  };

  return (
    <h1
      ref={containerRef}
      className={`text-scatter-title ${className}`}
      onClick={handleClick}
      style={{
        fontFamily: "'Outfit', sans-serif",
        fontSize: 'clamp(4.2rem, 11.2vw, 8.6rem)',
        fontWeight: 900,
        lineHeight: 0.92,
        color: '#000000',
        letterSpacing: '-0.03em',
        textTransform: 'uppercase',
        margin: '0 0 2.2rem 0',
        cursor: 'pointer',
        userSelect: 'none',
      }}
    >
      {lines.map((line, lineIdx) => (
        <React.Fragment key={lineIdx}>
          <span className="scatter-line">
            {line.split('').map((char, charIdx) => {
              if (char === ' ') {
                return <span key={charIdx} className="scatter-char space">&nbsp;</span>;
              }
              return (
                <span
                  key={charIdx}
                  className="scatter-char"
                  onMouseEnter={handleCharHover}
                >
                  {char}
                </span>
              );
            })}
            {dot && lineIdx === lines.length - 1 && (
              <span
                className="scatter-dot"
                onMouseEnter={handleCharHover}
                style={{
                  display: 'inline-block',
                  width: 'clamp(24px, 3.5vw, 42px)',
                  height: 'clamp(24px, 3.5vw, 42px)',
                  borderRadius: '50%',
                  background: '#b0b0b0',
                  marginLeft: '0.6rem',
                  verticalAlign: 'baseline'
                }}
              />
            )}
          </span>
          {lineIdx < lines.length - 1 && <br />}
        </React.Fragment>
      ))}
    </h1>
  );
}
